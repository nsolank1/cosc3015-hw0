module Main where

import Acme.Missiles

main :: IO ()
main = launchMissiles
